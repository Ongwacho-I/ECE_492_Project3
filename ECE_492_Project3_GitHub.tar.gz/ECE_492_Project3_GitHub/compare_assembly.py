
import re
from pathlib import Path

def instructions(filename):
    result = []

    for line in Path(filename).read_text().splitlines():

        # Parse objdump's address, bytes, and mnemonic
        parts = line.split("\t")

        if len(parts) < 3:
            continue

        instruction = parts[-1].strip()

        # Ignore NOP instructions
        if re.match(r"^nop(?:\s|$)", instruction):
            continue

        # Normalize addresses in branch targets
        instruction = re.sub(
            r"0x[0-9a-fA-F]+", "<address>", instruction
        )

        result.append(instruction)

    return result

a = instructions("assembly_480.txt")
b = instructions("assembly_496.txt")

print("Non-NOP instructions in 480:", len(a))
print("Non-NOP instructions in 496:", len(b))

if a == b:
    print("PASS: Non-NOP instructions match.")
else:
    print("DIFFERENCES FOUND:")
    import difflib

    for line in difflib.unified_diff(
        a, b,
        fromfile="480 NOP",
        tofile="496 NOP"
    ):
        print(line)
